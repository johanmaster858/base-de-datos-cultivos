# Manual de Marca - CultivosCO

## Introducción

Este manual de marca establece las directrices para el uso correcto de la identidad visual de CultivosCO, el Sistema de Recomendación de Cultivos para Colombia. Estas pautas aseguran una presentación coherente y profesional de la marca en todas las aplicaciones y plataformas.

## Índice

1. [Elementos de Marca](#1-elementos-de-marca)
2. [Logotipo](#2-logotipo)
3. [Paleta de Colores](#3-paleta-de-colores)
4. [Tipografía](#4-tipografía)
5. [Aplicaciones](#5-aplicaciones)
6. [Usos Incorrectos](#6-usos-incorrectos)

## 1. Elementos de Marca

### Nombre

El nombre oficial del proyecto es "CultivosCO", escrito como una sola palabra con las letras "CO" en mayúsculas. El nombre completo es "CultivosCO - Recomendador de Cultivos para Colombia".

### Concepto

CultivosCO representa la integración de tecnología y agricultura para optimizar la producción agrícola en Colombia. El concepto visual se basa en elementos naturales estilizados que simbolizan:

- **Círculo verde**: La tierra fértil y el campo colombiano
- **Planta estilizada**: El crecimiento y desarrollo de los cultivos
- **Sol**: El clima y las condiciones ambientales esenciales para la agricultura

## 2. Logotipo

### Versión Principal

![Logo con texto](/home/ubuntu/proyecto_cultivos/docs/branding/logo_with_text.png)

La versión principal incluye el símbolo y el nombre "CultivosCO" con el subtítulo "Recomendador de Cultivos".

### Símbolo

![Logo](/home/ubuntu/proyecto_cultivos/docs/branding/logo.png)

El símbolo puede utilizarse de forma independiente cuando el espacio es limitado o cuando la marca ya es reconocible en el contexto.

### Favicon

![Favicon](/home/ubuntu/proyecto_cultivos/docs/branding/favicon.ico)

Versión simplificada para uso en navegadores web y aplicaciones.

### Área de Protección

Debe mantenerse un espacio libre alrededor del logotipo equivalente a la altura de la letra "C" de "CultivosCO" para asegurar su visibilidad e impacto.

### Tamaño Mínimo

- Versión con texto: 120px de ancho
- Símbolo solo: 32px de ancho

## 3. Paleta de Colores

### Colores Principales

- **Verde Primario**: #2E7D32
  - RGB: 46, 125, 50
  - CMYK: 63%, 0%, 60%, 51%
  - Representa la tierra fértil y la agricultura sostenible

- **Verde Secundario**: #81C784
  - RGB: 129, 199, 132
  - CMYK: 35%, 0%, 34%, 22%
  - Representa el crecimiento y la vitalidad de los cultivos

### Colores Complementarios

- **Ámbar**: #FFC107
  - RGB: 255, 193, 7
  - CMYK: 0%, 24%, 97%, 0%
  - Representa el sol y la energía

- **Negro Texto**: #212121
  - RGB: 33, 33, 33
  - CMYK: 0%, 0%, 0%, 87%
  - Para textos y contenido principal

- **Blanco**: #FFFFFF
  - RGB: 255, 255, 255
  - CMYK: 0%, 0%, 0%, 0%
  - Para fondos y espacios negativos

## 4. Tipografía

### Tipografía Principal

**DejaVu Sans**
- Utilizada para el logotipo y títulos principales
- Versión Bold para "CultivosCO"
- Versión Regular para "Recomendador de Cultivos"

### Tipografía Secundaria

**Segoe UI** (para aplicaciones web y documentos)
- Regular para cuerpo de texto
- Semibold para subtítulos
- Bold para destacados

### Tipografía Alternativa

En caso de no disponer de las fuentes principales, se puede utilizar:
- **Arial** o **Helvetica** para títulos
- **Verdana** para cuerpo de texto

## 5. Aplicaciones

### Sitio Web

- Fondo blanco con acentos en verde primario
- Navegación y botones en verde primario
- Iconos en verde secundario o ámbar para destacados
- Textos en negro (#212121)

### Documentación

- Encabezados en verde primario
- Subtítulos en verde secundario
- Texto principal en negro
- Destacados en ámbar
- Fondos en blanco o tonos muy claros de verde

### Presentaciones

- Diapositivas con fondo blanco y acentos verdes
- Títulos en verde primario
- Gráficos utilizando la paleta completa
- El logotipo debe aparecer en la primera y última diapositiva

## 6. Usos Incorrectos

- No alterar las proporciones del logotipo
- No cambiar los colores establecidos
- No aplicar efectos como sombras o brillos
- No rotar o distorsionar el logotipo
- No cambiar la tipografía
- No colocar el logotipo sobre fondos que reduzcan su legibilidad
- No eliminar elementos del símbolo

---

## Contacto

Para consultas sobre el uso de la marca o solicitud de archivos adicionales:

**Correo**: marca@cultivosco.co  
**Web**: www.cultivosco.co/marca

---

© 2025 CultivosCO. Todos los derechos reservados.
