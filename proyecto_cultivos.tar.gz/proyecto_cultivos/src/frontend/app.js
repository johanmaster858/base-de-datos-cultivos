/* app.js - Funcionalidad principal para la aplicación de recomendación de cultivos */

// Configuración global
const API_URL = '/api';
const ASSETS_PATH = 'assets/cultivos/';

// Elementos DOM principales
const recomendadorForm = document.getElementById('recomendadorForm');
const resultadosSection = document.getElementById('resultados');
const resultadosContainer = document.getElementById('resultadosContainer');
const catalogoCultivos = document.getElementById('catalogoCultivos');

// Datos globales
let cultivos = [];
let recomendaciones = [];

// Inicialización cuando el DOM está completamente cargado
document.addEventListener('DOMContentLoaded', () => {
    // Inicializar navegación por pestañas
    inicializarNavegacion();
    
    // Cargar datos de cultivos para el catálogo
    cargarCatalogoCultivos();
    
    // Configurar eventos de formulario
    configurarFormulario();
    
    // Configurar filtros del catálogo
    configurarFiltrosCatalogo();
    
    // Configurar modal de detalles
    configurarModalDetalles();
});

// Función para navegar entre pestañas del formulario
function nextTab(tabId) {
    const tab = document.getElementById(tabId);
    const bsTab = new bootstrap.Tab(tab);
    bsTab.show();
}

// Inicializar componentes de navegación
function inicializarNavegacion() {
    // Manejar navegación del menú principal
    document.querySelectorAll('.navbar-nav a.nav-link').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const targetId = link.getAttribute('href').substring(1);
            document.getElementById(targetId).scrollIntoView({ behavior: 'smooth' });
        });
    });
}

// Configurar eventos del formulario de recomendación
function configurarFormulario() {
    recomendadorForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        // Mostrar indicador de carga
        mostrarCargando(resultadosContainer);
        
        // Recopilar datos del formulario
        const formData = recopilarDatosFormulario();
        
        try {
            // Enviar datos al servidor y obtener recomendaciones
            const recomendaciones = await obtenerRecomendaciones(formData);
            
            // Mostrar resultados
            mostrarResultados(recomendaciones);
            
            // Hacer visible la sección de resultados
            resultadosSection.classList.remove('d-none');
            resultadosSection.scrollIntoView({ behavior: 'smooth' });
        } catch (error) {
            console.error('Error al obtener recomendaciones:', error);
            mostrarError(resultadosContainer, 'No se pudieron obtener recomendaciones. Por favor, intenta nuevamente.');
        }
    });
}

// Recopilar todos los datos del formulario
function recopilarDatosFormulario() {
    return {
        // Ubicación
        departamento: document.getElementById('departamento').value,
        municipio: document.getElementById('municipio').value,
        altitud: parseFloat(document.getElementById('altitud').value),
        temperatura: parseFloat(document.getElementById('temperatura').value),
        precipitacion: parseFloat(document.getElementById('precipitacion').value),
        
        // Suelo
        tipo_suelo: document.getElementById('tipoSuelo').value,
        ph_suelo: document.getElementById('phSuelo').value ? parseFloat(document.getElementById('phSuelo').value) : null,
        drenaje: document.getElementById('drenaje').value,
        
        // Recursos
        area_disponible: document.getElementById('areaDisponible').value ? parseFloat(document.getElementById('areaDisponible').value) : 1,
        presupuesto: document.getElementById('presupuesto').value ? parseFloat(document.getElementById('presupuesto').value) : null,
        tiempo_disponible: document.getElementById('tiempoDisponible').value ? parseInt(document.getElementById('tiempoDisponible').value) : null,
        mano_obra: document.getElementById('manoObra').value,
        sistema_riego: document.getElementById('sistemaRiego').value,
        
        // Preferencias
        experiencia: document.getElementById('experiencia').value,
        preferencia_mercado: document.getElementById('preferenciaMercado').value,
        tipos_cultivo: obtenerTiposCultivoSeleccionados(),
        prioridades: obtenerPrioridadesSeleccionadas()
    };
}

// Obtener tipos de cultivo seleccionados
function obtenerTiposCultivoSeleccionados() {
    const tipos = [];
    if (document.getElementById('tipoCereal').checked) tipos.push('Cereal');
    if (document.getElementById('tipoFrutal').checked) tipos.push('Frutal');
    if (document.getElementById('tipoHortaliza').checked) tipos.push('Hortaliza');
    if (document.getElementById('tipoLeguminosa').checked) tipos.push('Leguminosa');
    return tipos;
}

// Obtener prioridades seleccionadas
function obtenerPrioridadesSeleccionadas() {
    const prioridades = [];
    if (document.getElementById('prioridadRentabilidad').checked) prioridades.push('rentabilidad');
    if (document.getElementById('prioridadFacilidad').checked) prioridades.push('facilidad');
    if (document.getElementById('prioridadSostenibilidad').checked) prioridades.push('sostenibilidad');
    return prioridades;
}

// Función para obtener recomendaciones del servidor
async function obtenerRecomendaciones(formData) {
    // En un entorno real, esto sería una llamada a la API
    // Por ahora, simulamos la respuesta con datos de ejemplo
    
    // Simulación de tiempo de procesamiento
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Para la demostración, usamos datos de ejemplo
    return simularRecomendaciones(formData);
}

// Función para simular recomendaciones basadas en los datos del formulario
function simularRecomendaciones(formData) {
    // Filtrar cultivos según condiciones básicas
    let cultivosFiltrados = cultivos.filter(cultivo => {
        // Verificar condiciones de temperatura
        const tempOk = formData.temperatura >= cultivo.condiciones.temp_min && 
                      formData.temperatura <= cultivo.condiciones.temp_max;
        
        // Verificar condiciones de altitud
        const altitudOk = formData.altitud >= cultivo.condiciones.altitud_min && 
                         formData.altitud <= cultivo.condiciones.altitud_max;
        
        // Verificar condiciones de precipitación
        const precipitacionOk = formData.precipitacion >= cultivo.condiciones.precipitacion_min && 
                               formData.precipitacion <= cultivo.condiciones.precipitacion_max;
        
        return tempOk && altitudOk && precipitacionOk;
    });
    
    // Si no hay resultados, relajar los criterios
    if (cultivosFiltrados.length === 0) {
        cultivosFiltrados = cultivos.filter(cultivo => {
            // Relajar criterios con un margen de tolerancia
            const margenTemp = 3;
            const margenAltitud = 300;
            const margenPrecip = 300;
            
            const tempOk = (formData.temperatura >= cultivo.condiciones.temp_min - margenTemp) && 
                          (formData.temperatura <= cultivo.condiciones.temp_max + margenTemp);
            
            const altitudOk = (formData.altitud >= cultivo.condiciones.altitud_min - margenAltitud) && 
                             (formData.altitud <= cultivo.condiciones.altitud_max + margenAltitud);
            
            const precipitacionOk = (formData.precipitacion >= cultivo.condiciones.precipitacion_min - margenPrecip) && 
                                   (formData.precipitacion <= cultivo.condiciones.precipitacion_max + margenPrecip);
            
            return tempOk && altitudOk && precipitacionOk;
        });
    }
    
    // Filtrar por tipo de suelo si se especificó
    if (formData.tipo_suelo && formData.tipo_suelo !== 'No sé') {
        const cultivosConSueloCompatible = cultivosFiltrados.filter(cultivo => 
            cultivo.condiciones.tipo_suelo.toLowerCase().includes(formData.tipo_suelo.toLowerCase())
        );
        
        // Solo aplicar el filtro si hay resultados
        if (cultivosConSueloCompatible.length > 0) {
            cultivosFiltrados = cultivosConSueloCompatible;
        }
    }
    
    // Filtrar por pH si se especificó
    if (formData.ph_suelo) {
        const cultivosConPhCompatible = cultivosFiltrados.filter(cultivo => 
            formData.ph_suelo >= cultivo.condiciones.ph_min && 
            formData.ph_suelo <= cultivo.condiciones.ph_max
        );
        
        // Solo aplicar el filtro si hay resultados
        if (cultivosConPhCompatible.length > 0) {
            cultivosFiltrados = cultivosConPhCompatible;
        }
    }
    
    // Filtrar por presupuesto si se especificó
    if (formData.presupuesto) {
        const cultivosEnPresupuesto = cultivosFiltrados.filter(cultivo => 
            cultivo.costos && cultivo.costos.inversion_min <= formData.presupuesto
        );
        
        // Solo aplicar el filtro si hay resultados
        if (cultivosEnPresupuesto.length > 0) {
            cultivosFiltrados = cultivosEnPresupuesto;
        }
    }
    
    // Filtrar por tiempo disponible si se especificó
    if (formData.tiempo_disponible) {
        const cultivosEnTiempo = cultivosFiltrados.filter(cultivo => 
            cultivo.ciclo_dias <= formData.tiempo_disponible
        );
        
        // Solo aplicar el filtro si hay resultados
        if (cultivosEnTiempo.length > 0) {
            cultivosFiltrados = cultivosEnTiempo;
        }
    }
    
    // Filtrar por tipos de cultivo seleccionados
    if (formData.tipos_cultivo && formData.tipos_cultivo.length > 0) {
        const cultivosPorTipo = cultivosFiltrados.filter(cultivo => 
            formData.tipos_cultivo.includes(cultivo.tipo)
        );
        
        // Solo aplicar el filtro si hay resultados
        if (cultivosPorTipo.length > 0) {
            cultivosFiltrados = cultivosPorTipo;
        }
    }
    
    // Calcular puntuación para cada cultivo
    cultivosFiltrados.forEach(cultivo => {
        let puntuacion = 100;
        
        // Ajustar por cercanía a condiciones óptimas
        const tempOptima = (cultivo.condiciones.temp_min + cultivo.condiciones.temp_max) / 2;
        const distanciaTemp = Math.abs(formData.temperatura - tempOptima);
        const rangoTemp = cultivo.condiciones.temp_max - cultivo.condiciones.temp_min;
        puntuacion -= (distanciaTemp / rangoTemp) * 20;
        
        const altitudOptima = (cultivo.condiciones.altitud_min + cultivo.condiciones.altitud_max) / 2;
        const distanciaAltitud = Math.abs(formData.altitud - altitudOptima);
        const rangoAltitud = cultivo.condiciones.altitud_max - cultivo.condiciones.altitud_min;
        puntuacion -= (distanciaAltitud / rangoAltitud) * 15;
        
        // Ajustar por rentabilidad si es una prioridad
        if (formData.prioridades.includes('rentabilidad') && cultivo.costos) {
            if (cultivo.costos.rentabilidad > 25) puntuacion += 15;
            else if (cultivo.costos.rentabilidad > 15) puntuacion += 10;
            else puntuacion += 5;
        }
        
        // Ajustar por facilidad si es una prioridad
        if (formData.prioridades.includes('facilidad')) {
            // Simplificación: algunos cultivos son más fáciles que otros
            const cultivosFaciles = ['Maíz', 'Fríjol', 'Yuca', 'Plátano'];
            const cultivosDificiles = ['Café', 'Cacao', 'Gulupa', 'Arándano'];
            
            if (cultivosFaciles.includes(cultivo.nombre)) puntuacion += 15;
            else if (cultivosDificiles.includes(cultivo.nombre)) puntuacion -= 10;
        }
        
        // Ajustar por experiencia del usuario
        if (formData.experiencia) {
            const cultivosFaciles = ['Maíz', 'Fríjol', 'Yuca', 'Plátano'];
            const cultivosMedios = ['Arroz', 'Papa', 'Tomate de árbol'];
            const cultivosDificiles = ['Café', 'Cacao', 'Gulupa', 'Arándano'];
            
            if (formData.experiencia === 'Baja') {
                if (cultivosFaciles.includes(cultivo.nombre)) puntuacion += 15;
                else if (cultivosDificiles.includes(cultivo.nombre)) puntuacion -= 15;
            } else if (formData.experiencia === 'Media') {
                if (cultivosMedios.includes(cultivo.nombre)) puntuacion += 10;
            } else if (formData.experiencia === 'Alta') {
                if (cultivosDificiles.includes(cultivo.nombre)) puntuacion += 15;
            }
        }
        
        // Ajustar por preferencia de mercado
        if (formData.preferencia_mercado && cultivo.costos) {
            if (formData.preferencia_mercado === 'Exportación' && cultivo.costos.precio_export) {
                puntuacion += 15;
            } else if (formData.preferencia_mercado === 'Local' && cultivo.costos.precio_interno) {
                puntuacion += 15;
            }
        }
        
        // Asegurar que la puntuación esté en el rango 0-100
        cultivo.puntuacion = Math.max(0, Math.min(100, Math.round(puntuacion)));
    });
    
    // Ordenar por puntuación y seleccionar los mejores
    return cultivosFiltrados
        .sort((a, b) => b.puntuacion - a.puntuacion)
        .slice(0, 10);
}

// Mostrar resultados de recomendaciones
function mostrarResultados(recomendaciones) {
    // Guardar recomendaciones globalmente
    window.recomendaciones = recomendaciones;
    
    // Limpiar contenedor
    resultadosContainer.innerHTML = '';
    
    if (recomendaciones.length === 0) {
        resultadosContainer.innerHTML = `
            <div class="col-12 text-center">
                <div class="alert alert-warning">
                    <i class="bi bi-exclamation-triangle"></i> No se encontraron cultivos que coincidan con tus criterios.
                    Intenta ajustar algunos parámetros para obtener recomendaciones.
                </div>
            </div>
        `;
        return;
    }
    
    // Mostrar cada recomendación
    recomendaciones.forEach(cultivo => {
        const card = document.createElement('div');
        card.className = 'col-md-6 col-lg-4';
        card.innerHTML = `
            <div class="card h-100 border-0 shadow-sm">
                <div class="card-header bg-primary text-white">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">${cultivo.nombre}</h5>
                        <span class="badge bg-light text-primary">${cultivo.puntuacion}% compatible</span>
                    </div>
                </div>
                <img src="${ASSETS_PATH}${cultivo.imagen || 'default.jpg'}" class="card-img-top" alt="${cultivo.nombre}" style="height: 200px; object-fit: cover;">
                <div class="card-body">
                    <p class="card-text">${cultivo.descripcion.substring(0, 120)}...</p>
                    <div class="d-flex justify-content-between align-items-center">
                        <span class="badge bg-secondary">${cultivo.tipo}</span>
                        <span>Ciclo: ${cultivo.ciclo_dias} días</span>
                    </div>
                    <hr>
                    <h6>Condiciones óptimas:</h6>
                    <ul class="list-unstyled small">
                        <li><i class="bi bi-thermometer-half"></i> ${cultivo.condiciones.temp_min} - ${cultivo.condiciones.temp_max} °C</li>
                        <li><i class="bi bi-cloud-rain"></i> ${cultivo.condiciones.precipitacion_min} - ${cultivo.condiciones.precipitacion_max} mm/año</li>
                        <li><i class="bi bi-geo-alt"></i> ${cultivo.condiciones.altitud_min} - ${cultivo.condiciones.altitud_max} msnm</li>
                    </ul>
                </div>
                <div class="card-footer bg-white border-0">
                    <div class="d-grid gap-2">
                        <button class="btn btn-outline-primary" onclick="mostrarDetallesCultivo(${cultivo.id_cultivo})">
                            Ver detalles completos
                        </button>
                    </div>
                </div>
            </div>
        `;
        resultadosContainer.appendChild(card);
    });
}

// Cargar datos de cultivos para el catálogo
async function cargarCatalogoCultivos() {
    try {
        // En un entorno real, esto sería una llamada a la API
        // Por ahora, cargamos datos de ejemplo
        cultivos = await cargarDatosEjemplo();
        
        // Mostrar cultivos en el catálogo
        mostrarCatalogoCultivos(cultivos);
    } catch (error) {
        console.error('Error al cargar cultivos:', error);
        mostrarError(catalogoCultivos, 'No se pudieron cargar los cultivos. Por favor, recarga la página.');
    }
}

// Mostrar cultivos en el catálogo
function mostrarCatalogoCultivos(cultivos) {
    // Limpiar contenedor
    catalogoCultivos.innerHTML = '';
    
    // Mostrar cada cultivo
    cultivos.forEach(cultivo => {
        const card = document.createElement('div');
        card.className = 'col-md-4 col-lg-3 mb-4';
        card.innerHTML = `
            <div class="card h-100 border-0 shadow-sm">
                <img src="${ASSETS_PATH}${cultivo.imagen || 'default.jpg'}" class="card-img-top" alt="${cultivo.nombre}" style="height: 180px; object-fit: cover;">
                <div class="card-body">
                    <h5 class="card-title">${cultivo.nombre}</h5>
                    <p class="card-text small">${cultivo.descripcion.substring(0, 80)}...</p>
                    <div class="d-flex justify-content-between align-items-center">
                        <span class="badge bg-primary">${cultivo.tipo}</span>
                        <button class="btn btn-sm btn-outline-primary" onclick="mostrarDetallesCultivo(${cultivo.id_cultivo})">
                            Ver detalles
                        </button>
                    </div>
                </div>
            </div>
        `;
        catalogoCultivos.appendChild(card);
    });
}

// Configurar filtros del catálogo
function configurarFiltrosCatalogo() {
    // Filtro por categoría
    document.getElementById('filtroCategoría').addEventListener('change', aplicarFiltrosCatalogo);
    
    // Filtro por altitud
    document.getElementById('filtroAltitud').addEventListener('change', aplicarFiltrosCatalogo);
    
    // Filtro por ciclo
    document.getElementById('filtroCiclo').addEventListener('change', aplicarFiltrosCatalogo);
    
    // Búsqueda por nombre
    document.getElementById('busquedaCultivo').addEventListener('input', aplicarFiltrosCatalogo);
}

// Aplicar filtros al catálogo
function aplicarFiltrosCatalogo() {
    const categoria = document.getElementById('filtroCategoría').value;
    const altitud = document.getElementById('filtroAltitud').value;
    const ciclo = document.getElementById('filtroCiclo').value;
    const busqueda = document.getElementById('busquedaCultivo').value.toLowerCase();
    
    // Filtrar cultivos
    let cultivosFiltrados = cultivos;
    
    // Filtrar por categoría
    if (categoria !== 'todos') {
        cultivosFiltrados = cultivosFiltrados.filter(cultivo => cultivo.tipo === categoria);
    }
    
    // Filtrar por altitud
    if (altitud !== 'todos') {
        const [min, max] = altitud.split('-').map(val => val === '+' ? Infinity : parseInt(val));
        cultivosFiltrados = cultivosFiltrados.filter(cultivo => {
            const altitudMedia = (cultivo.condiciones.altitud_min + cultivo.condiciones.altitud_max) / 2;
            return altitudMedia >= min && altitudMedia <= max;
        });
    }
    
    // Filtrar por ciclo
    if (ciclo !== 'todos') {
        if (ciclo === 'corto') {
            cultivosFiltrados = cultivosFiltrados.filter(cultivo => cultivo.ciclo_dias < 180);
        } else if (ciclo === 'medio') {
            cultivosFiltrados = cultivosFiltrados.filter(cultivo => cultivo.ciclo_dias >= 180 && cultivo.ciclo_dias <= 365);
        } else if (ciclo === 'largo') {
            cultivosFiltrados = cultivosFiltrados.filter(cultivo => cultivo.ciclo_dias > 365);
        }
    }
    
    // Filtrar por búsqueda
    if (busqueda) {
        cultivosFiltrados = cultivosFiltrados.filter(cultivo => 
            cultivo.nombre.toLowerCase().includes(busqueda) || 
            cultivo.descripcion.toLowerCase().includes(busqueda)
        );
    }
    
    // Mostrar resultados filtrados
    mostrarCatalogoCultivos(cultivosFiltrados);
}

// Configurar modal de detalles
function configurarModalDetalles() {
    // Configurar botón de cálculo de costos
    document.getElementById('btnCalcularCostos').addEventListener('click', () => {
        const idCultivo = document.getElementById('cultivoModal').getAttribute('data-cultivo-id');
        mostrarCalculadoraCostos(idCultivo);
    });
}

// Mostrar detalles de un cultivo específico
function mostrarDetallesCultivo(idCultivo) {
    // Buscar cultivo por ID
    const cultivo = cultivos.find(c => c.id_cultivo === idCultivo);
    
    if (!cultivo) {
        console.error('Cultivo no encontrado:', idCultivo);
        return;
    }
    
    // Actualizar modal con datos del cultivo
    const modal = document.getElementById('cultivoModal');
    modal.setAttribute('data-cultivo-id', idCultivo);
    
    // Actualizar título y datos básicos
    document.getElementById('cultivoModalLabel').textContent = `Detalles de ${cultivo.nombre}`;
    document.getElementById('cultivoModalNombre').textContent = cultivo.nombre;
    document.getElementById('cultivoModalDescripcion').textContent = cultivo.descripcion;
    document.getElementById('cultivoModalImagen').src = `${ASSETS_PATH}${cultivo.imagen || 'default.jpg'}`;
    document.getElementById('cultivoModalTipo').textContent = cultivo.tipo;
    document.getElementById('cultivoModalCiclo').textContent = `${cultivo.ciclo_dias} días`;
    document.getElementById('cultivoModalDensidad').textContent = cultivo.densidad_siembra;
    
    // Actualizar condiciones óptimas
    document.getElementById('cultivoModalTemperatura').textContent = `${cultivo.condiciones.temp_min} - ${cultivo.condiciones.temp_max} °C`;
    document.getElementById('cultivoModalPrecipitacion').textContent = `${cultivo.condiciones.precipitacion_min} - ${cultivo.condiciones.precipitacion_max} mm/año`;
    document.getElementById('cultivoModalAltitud').textContent = `${cultivo.condiciones.altitud_min} - ${cultivo.condiciones.altitud_max} msnm`;
    document.getElementById('cultivoModalSuelo').textContent = cultivo.condiciones.tipo_suelo;
    document.getElementById('cultivoModalPH').textContent = `${cultivo.condiciones.ph_min} - ${cultivo.condiciones.ph_max}`;
    
    // Zonas productoras (simulado)
    document.getElementById('cultivoModalZonas').textContent = obtenerZonasProductoras(cultivo);
    
    // Actualizar costos y rentabilidad
    if (cultivo.costos) {
        document.getElementById('cultivoModalInversion').textContent = `${formatearPrecio(cultivo.costos.inversion_min)} - ${formatearPrecio(cultivo.costos.inversion_max)}`;
        document.getElementById('cultivoModalCostoOperativo').textContent = formatearPrecio(cultivo.costos.costo_operativo);
        document.getElementById('cultivoModalPrecioInterno').textContent = cultivo.costos.precio_interno ? `${formatearPrecio(cultivo.costos.precio_interno)}/kg` : 'No disponible';
        document.getElementById('cultivoModalPrecioExport').textContent = cultivo.costos.precio_export ? `${cultivo.costos.precio_export.toFixed(2)} USD/kg` : 'No disponible';
        document.getElementById('cultivoModalRentabilidad').textContent = `${cultivo.costos.rentabilidad}%`;
    }
    
    // Insumos principales (simulado)
    document.getElementById('cultivoModalInsumos').innerHTML = obtenerInsumosHTML(cultivo);
    
    // Plagas y enfermedades (simulado)
    document.getElementById('cultivoModalPlagas').innerHTML = obtenerPlagasHTML(cultivo);
    
    // Técnicas de cultivo (simulado)
    document.getElementById('cultivoModalTecnicas').innerHTML = obtenerTecnicasHTML(cultivo);
    
    // Mostrar modal
    const modalElement = new bootstrap.Modal(modal);
    modalElement.show();
}

// Obtener HTML para zonas productoras
function obtenerZonasProductoras(cultivo) {
    // Simulación de zonas productoras según el tipo de cultivo
    const zonasPorTipo = {
        'Cereal': 'Tolima, Valle del Cauca, Meta, Córdoba',
        'Frutal': 'Antioquia, Valle del Cauca, Cundinamarca, Santander',
        'Leguminosa': 'Huila, Tolima, Antioquia, Santander',
        'Tubérculo': 'Cundinamarca, Boyacá, Nariño, Antioquia',
        'Estimulante': 'Huila, Caldas, Antioquia, Tolima, Cauca',
        'Oleaginosa': 'Meta, Casanare, Santander, Cesar'
    };
    
    return zonasPorTipo[cultivo.tipo] || 'Información no disponible';
}

// Obtener HTML para insumos
function obtenerInsumosHTML(cultivo) {
    // Simulación de insumos según el tipo de cultivo
    const insumosPorTipo = {
        'Cereal': [
            { nombre: 'Semilla certificada', cantidad: '20-25 kg/ha', precio: '35,000 COP/kg' },
            { nombre: 'Fertilizante NPK', cantidad: '300 kg/ha', precio: '2,800 COP/kg' },
            { nombre: 'Herbicida pre-emergente', cantidad: '2 l/ha', precio: '25,000 COP/l' }
        ],
        'Frutal': [
            { nombre: 'Plántulas certificadas', cantidad: '1,000-2,000 unidades/ha', precio: '3,500 COP/unidad' },
            { nombre: 'Fertilizante orgánico', cantidad: '5,000 kg/ha', precio: '500 COP/kg' },
            { nombre: 'Fungicida preventivo', cantidad: '3 kg/ha', precio: '28,000 COP/kg' }
        ],
        'Leguminosa': [
            { nombre: 'Semilla certificada', cantidad: '80-100 kg/ha', precio: '12,000 COP/kg' },
            { nombre: 'Inoculante de Rhizobium', cantidad: '1 kg/ha', precio: '45,000 COP/kg' },
            { nombre: 'Insecticida biológico', cantidad: '1 l/ha', precio: '35,000 COP/l' }
        ],
        'Tubérculo': [
            { nombre: 'Tubérculo-semilla', cantidad: '2,000 kg/ha', precio: '3,500 COP/kg' },
            { nombre: 'Fertilizante compuesto', cantidad: '800 kg/ha', precio: '2,900 COP/kg' },
            { nombre: 'Fungicida sistémico', cantidad: '2 kg/ha', precio: '45,000 COP/kg' }
        ],
        'Estimulante': [
            { nombre: 'Plántulas certificadas', cantidad: '1,000-1,500 unidades/ha', precio: '5,000 COP/unidad' },
            { nombre: 'Fertilizante de liberación lenta', cantidad: '500 kg/ha', precio: '3,200 COP/kg' },
            { nombre: 'Control biológico', cantidad: '5 dosis/ha', precio: '40,000 COP/dosis' }
        ]
    };
    
    const insumos = insumosPorTipo[cultivo.tipo] || [];
    
    if (insumos.length === 0) {
        return '<p>Información de insumos no disponible</p>';
    }
    
    let html = '<div class="table-responsive"><table class="table table-sm table-striped">';
    html += '<thead><tr><th>Insumo</th><th>Cantidad/ha</th><th>Precio referencia</th></tr></thead><tbody>';
    
    insumos.forEach(insumo => {
        html += `<tr>
            <td>${insumo.nombre}</td>
            <td>${insumo.cantidad}</td>
            <td>${insumo.precio}</td>
        </tr>`;
    });
    
    html += '</tbody></table></div>';
    return html;
}

// Obtener HTML para plagas y enfermedades
function obtenerPlagasHTML(cultivo) {
    // Simulación de plagas según el tipo de cultivo
    const plagasPorTipo = {
        'Cereal': [
            { nombre: 'Gusano cogollero', tipo: 'Insecto', severidad: 'Alta', control: 'Control biológico con Bacillus thuringiensis, control químico con insecticidas específicos.' },
            { nombre: 'Roya', tipo: 'Hongo', severidad: 'Media', control: 'Fungicidas sistémicos, variedades resistentes, rotación de cultivos.' }
        ],
        'Frutal': [
            { nombre: 'Mosca de la fruta', tipo: 'Insecto', severidad: 'Alta', control: 'Trampas con atrayentes, control químico, manejo de frutos caídos.' },
            { nombre: 'Antracnosis', tipo: 'Hongo', severidad: 'Media', control: 'Fungicidas protectantes y sistémicos, manejo de humedad.' }
        ],
        'Leguminosa': [
            { nombre: 'Trips', tipo: 'Insecto', severidad: 'Media', control: 'Control biológico con ácaros depredadores, insecticidas específicos.' },
            { nombre: 'Mildeo polvoso', tipo: 'Hongo', severidad: 'Media', control: 'Fungicidas a base de azufre, manejo de humedad.' }
        ],
        'Tubérculo': [
            { nombre: 'Gota de la papa', tipo: 'Oomiceto', severidad: 'Alta', control: 'Fungicidas preventivos y curativos, variedades resistentes, manejo de humedad.' },
            { nombre: 'Polilla guatemalteca', tipo: 'Insecto', severidad: 'Alta', control: 'Manejo integrado, trampas de feromonas, control químico.' }
        ],
        'Estimulante': [
            { nombre: 'Broca del café', tipo: 'Insecto', severidad: 'Alta', control: 'Control cultural (RE-RE), control biológico con Beauveria bassiana, trampas.' },
            { nombre: 'Roya del café', tipo: 'Hongo', severidad: 'Alta', control: 'Fungicidas cúpricos, variedades resistentes, manejo de sombra.' }
        ]
    };
    
    const plagas = plagasPorTipo[cultivo.tipo] || [];
    
    if (plagas.length === 0) {
        return '<p>Información de plagas y enfermedades no disponible</p>';
    }
    
    let html = '';
    
    plagas.forEach(plaga => {
        html += `
        <div class="card mb-3">
            <div class="card-header">
                <div class="d-flex justify-content-between align-items-center">
                    <h6 class="mb-0">${plaga.nombre}</h6>
                    <span class="badge bg-${plaga.severidad === 'Alta' ? 'danger' : 'warning'}">${plaga.severidad}</span>
                </div>
            </div>
            <div class="card-body">
                <p class="card-text small mb-1"><strong>Tipo:</strong> ${plaga.tipo}</p>
                <p class="card-text small mb-0"><strong>Control recomendado:</strong> ${plaga.control}</p>
            </div>
        </div>`;
    });
    
    return html;
}

// Obtener HTML para técnicas de cultivo
function obtenerTecnicasHTML(cultivo) {
    // Simulación de técnicas según el tipo de cultivo
    const tecnicasPorTipo = {
        'Cereal': [
            { nombre: 'Labranza mínima', importancia: 'Recomendada', descripcion: 'Técnica que minimiza la perturbación del suelo, manteniendo cobertura vegetal.' },
            { nombre: 'Rotación de cultivos', importancia: 'Esencial', descripcion: 'Alternancia de diferentes cultivos en la misma área para mejorar fertilidad y reducir plagas.' }
        ],
        'Frutal': [
            { nombre: 'Riego por goteo', importancia: 'Esencial', descripcion: 'Sistema de riego localizado que aplica agua directamente a la zona radicular.' },
            { nombre: 'Poda de formación', importancia: 'Esencial', descripcion: 'Técnica para dar estructura al árbol y mejorar producción y calidad de frutos.' }
        ],
        'Leguminosa': [
            { nombre: 'Inoculación de semillas', importancia: 'Recomendada', descripcion: 'Aplicación de bacterias fijadoras de nitrógeno para mejorar nutrición.' },
            { nombre: 'Asociación de cultivos', importancia: 'Opcional', descripcion: 'Siembra simultánea con otros cultivos compatibles para optimizar espacio.' }
        ],
        'Tubérculo': [
            { nombre: 'Aporque', importancia: 'Esencial', descripcion: 'Acumulación de tierra alrededor de la base de la planta para estimular tuberización.' },
            { nombre: 'Manejo integrado de plagas', importancia: 'Esencial', descripcion: 'Estrategia que combina diferentes métodos de control de plagas.' }
        ],
        'Estimulante': [
            { nombre: 'Manejo de sombra', importancia: 'Esencial', descripcion: 'Regulación de la cantidad de luz que recibe el cultivo mediante árboles de sombra.' },
            { nombre: 'Renovación de plantaciones', importancia: 'Recomendada', descripcion: 'Sustitución programada de plantas viejas para mantener productividad.' }
        ]
    };
    
    const tecnicas = tecnicasPorTipo[cultivo.tipo] || [];
    
    if (tecnicas.length === 0) {
        return '<p>Información de técnicas de cultivo no disponible</p>';
    }
    
    let html = '';
    
    tecnicas.forEach(tecnica => {
        html += `
        <div class="card mb-3">
            <div class="card-header">
                <div class="d-flex justify-content-between align-items-center">
                    <h6 class="mb-0">${tecnica.nombre}</h6>
                    <span class="badge bg-${tecnica.importancia === 'Esencial' ? 'primary' : (tecnica.importancia === 'Recomendada' ? 'success' : 'secondary')}">${tecnica.importancia}</span>
                </div>
            </div>
            <div class="card-body">
                <p class="card-text small">${tecnica.descripcion}</p>
            </div>
        </div>`;
    });
    
    return html;
}

// Mostrar calculadora de costos
function mostrarCalculadoraCostos(idCultivo) {
    // Buscar cultivo por ID
    const cultivo = cultivos.find(c => c.id_cultivo === parseInt(idCultivo));
    
    if (!cultivo || !cultivo.costos) {
        alert('No se puede calcular costos para este cultivo');
        return;
    }
    
    // Solicitar área al usuario
    const area = prompt('Ingresa el área en hectáreas:', '1');
    
    if (!area || isNaN(parseFloat(area)) || parseFloat(area) <= 0) {
        alert('Área inválida');
        return;
    }
    
    const areaHa = parseFloat(area);
    
    // Calcular costos
    const inversionMin = cultivo.costos.inversion_min * areaHa;
    const inversionMax = cultivo.costos.inversion_max * areaHa;
    const costoOperativo = cultivo.costos.costo_operativo * areaHa;
    
    // Estimar ingresos (simplificado)
    let estimacionIngresos = 'No disponible';
    
    if (cultivo.costos.precio_interno) {
        // Estimación muy simplificada basada en rendimiento promedio
        const rendimientoEstimado = obtenerRendimientoEstimado(cultivo) * areaHa;
        const ingresosEstimados = rendimientoEstimado * cultivo.costos.precio_interno;
        estimacionIngresos = formatearPrecio(ingresosEstimados);
    }
    
    // Crear mensaje
    const mensaje = `
    <h4>Estimación de costos para ${cultivo.nombre}</h4>
    <p>Área: ${areaHa} hectáreas</p>
    
    <h5>Inversión inicial</h5>
    <p>${formatearPrecio(inversionMin)} - ${formatearPrecio(inversionMax)}</p>
    
    <h5>Costos operativos</h5>
    <p>${formatearPrecio(costoOperativo)}</p>
    
    <h5>Estimación de ingresos</h5>
    <p>${estimacionIngresos}</p>
    
    <h5>Rentabilidad estimada</h5>
    <p>${cultivo.costos.rentabilidad}%</p>
    `;
    
    // Mostrar resultados
    alert(mensaje);
}

// Obtener rendimiento estimado para un cultivo
function obtenerRendimientoEstimado(cultivo) {
    // Rendimientos promedio estimados por tipo (ton/ha)
    const rendimientosPorTipo = {
        'Cereal': 3.5,
        'Frutal': 15,
        'Leguminosa': 1.8,
        'Tubérculo': 18,
        'Estimulante': 1.2,
        'Oleaginosa': 2.5
    };
    
    return rendimientosPorTipo[cultivo.tipo] || 1;
}

// Formatear precio en COP
function formatearPrecio(valor) {
    return new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP', maximumFractionDigits: 0 }).format(valor);
}

// Mostrar indicador de carga
function mostrarCargando(elemento) {
    elemento.innerHTML = `
        <div class="col-12 text-center py-5">
            <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden">Cargando...</span>
            </div>
            <p class="mt-3">Procesando datos...</p>
        </div>
    `;
}

// Mostrar mensaje de error
function mostrarError(elemento, mensaje) {
    elemento.innerHTML = `
        <div class="col-12 text-center">
            <div class="alert alert-danger">
                <i class="bi bi-exclamation-circle"></i> ${mensaje}
            </div>
        </div>
    `;
}

// Cargar datos de ejemplo para la demostración
async function cargarDatosEjemplo() {
    // Simulación de tiempo de carga
    await new Promise(resolve => setTimeout(resolve, 500));
    
    // Datos de ejemplo basados en la base de datos
    return [
        {
            id_cultivo: 1,
            nombre: 'Maíz',
            descripcion: 'Cereal básico de la alimentación colombiana, cultivado tanto por pequeños agricultores como por medianos productores tecnificados.',
            tipo: 'Cereal',
            ciclo_dias: 120,
            densidad_siembra: '50,000-60,000 plantas/ha',
            imagen: 'maiz.jpg',
            condiciones: {
                temp_min: 24,
                temp_max: 30,
                precipitacion_min: 800,
                precipitacion_max: 1500,
                tipo_suelo: 'Franco, bien drenado',
                ph_min: 5.5,
                ph_max: 7.0,
                altitud_min: 0,
                altitud_max: 2700
            },
            costos: {
                inversion_min: 3000000,
                inversion_max: 5000000,
                costo_operativo: 2500000,
                precio_interno: 900,
                precio_export: null,
                rentabilidad: 15
            }
        },
        {
            id_cultivo: 12,
            nombre: 'Papa',
            descripcion: 'Tubérculo fundamental en la dieta de la región andina colombiana.',
            tipo: 'Tubérculo',
            ciclo_dias: 150,
            densidad_siembra: '40,000-50,000 plantas/ha',
            imagen: 'papa.jpg',
            condiciones: {
                temp_min: 12,
                temp_max: 18,
                precipitacion_min: 700,
                precipitacion_max: 1200,
                tipo_suelo: 'Franco volcánico',
                ph_min: 5.0,
                ph_max: 6.5,
                altitud_min: 2500,
                altitud_max: 3400
            },
            costos: {
                inversion_min: 8000000,
                inversion_max: 12000000,
                costo_operativo: 6000000,
                precio_interno: 1000,
                precio_export: null,
                rentabilidad: 25
            }
        },
        {
            id_cultivo: 33,
            nombre: 'Café',
            descripcion: 'Cultivo emblemático de Colombia, base de la economía agrícola en muchas regiones.',
            tipo: 'Estimulante',
            ciclo_dias: 1095,
            densidad_siembra: '625-1,100 plantas/ha',
            imagen: 'cafe.jpg',
            condiciones: {
                temp_min: 18,
                temp_max: 22,
                precipitacion_min: 1800,
                precipitacion_max: 2500,
                tipo_suelo: 'Franco arcilloso',
                ph_min: 5.5,
                ph_max: 6.5,
                altitud_min: 1200,
                altitud_max: 2000
            },
            costos: {
                inversion_min: 15000000,
                inversion_max: 20000000,
                costo_operativo: 8000000,
                precio_interno: 19000,
                precio_export: 2.25,
                rentabilidad: 25
            }
        },
        {
            id_cultivo: 19,
            nombre: 'Plátano',
            descripcion: 'Musácea fundamental en la dieta colombiana, cultivada en diversos sistemas.',
            tipo: 'Frutal',
            ciclo_dias: 300,
            densidad_siembra: '1,000-1,200 plantas/ha',
            imagen: 'platano.jpg',
            condiciones: {
                temp_min: 24,
                temp_max: 28,
                precipitacion_min: 2000,
                precipitacion_max: 3000,
                tipo_suelo: 'Franco',
                ph_min: 5.5,
                ph_max: 7.0,
                altitud_min: 0,
                altitud_max: 1400
            },
            costos: {
                inversion_min: 8000000,
                inversion_max: 12000000,
                costo_operativo: 5000000,
                precio_interno: 900,
                precio_export: null,
                rentabilidad: 20
            }
        },
        {
            id_cultivo: 7,
            nombre: 'Fríjol',
            descripcion: 'Leguminosa de gran importancia en la dieta colombiana, cultivada en diversos sistemas productivos.',
            tipo: 'Leguminosa',
            ciclo_dias: 105,
            densidad_siembra: '100,000-120,000 plantas/ha',
            imagen: 'frijol.jpg',
            condiciones: {
                temp_min: 18,
                temp_max: 26,
                precipitacion_min: 800,
                precipitacion_max: 1200,
                tipo_suelo: 'Franco, buen drenaje',
                ph_min: 5.5,
                ph_max: 6.5,
                altitud_min: 1000,
                altitud_max: 2100
            },
            costos: {
                inversion_min: 3500000,
                inversion_max: 5500000,
                costo_operativo: 3000000,
                precio_interno: 2250,
                precio_export: null,
                rentabilidad: 20
            }
        },
        {
            id_cultivo: 25,
            nombre: 'Gulupa',
            descripcion: 'Fruta de la pasión púrpura con alto valor en mercados de exportación.',
            tipo: 'Frutal',
            ciclo_dias: 1825,
            densidad_siembra: '800-1,000 plantas/ha',
            imagen: 'gulupa.jpg',
            condiciones: {
                temp_min: 12,
                temp_max: 18,
                precipitacion_min: 1500,
                precipitacion_max: 1800,
                tipo_suelo: 'Franco arcilloso',
                ph_min: 5.5,
                ph_max: 6.5,
                altitud_min: 2000,
                altitud_max: 2700
            },
            costos: {
                inversion_min: 15000000,
                inversion_max: 20000000,
                costo_operativo: 8000000,
                precio_interno: null,
                precio_export: 6.00,
                rentabilidad: 35
            }
        },
        {
            id_cultivo: 34,
            nombre: 'Cacao',
            descripcion: 'Cultivo tropical con creciente importancia en la economía agrícola colombiana.',
            tipo: 'Estimulante',
            ciclo_dias: 1825,
            densidad_siembra: '1,100 plantas/ha',
            imagen: 'cacao.jpg',
            condiciones: {
                temp_min: 23,
                temp_max: 28,
                precipitacion_min: 1500,
                precipitacion_max: 2500,
                tipo_suelo: 'Franco arcilloso',
                ph_min: 5.5,
                ph_max: 6.5,
                altitud_min: 0,
                altitud_max: 1200
            },
            costos: {
                inversion_min: 12000000,
                inversion_max: 18000000,
                costo_operativo: 6000000,
                precio_interno: 8500,
                precio_export: 3.00,
                rentabilidad: 30
            }
        },
        {
            id_cultivo: 32,
            nombre: 'Arándano',
            descripcion: 'Frutal de clima frío con creciente demanda internacional.',
            tipo: 'Frutal',
            ciclo_dias: 1825,
            densidad_siembra: '5,000 plantas/ha',
            imagen: 'arandano.jpg',
            condiciones: {
                temp_min: 13,
                temp_max: 18,
                precipitacion_min: 800,
                precipitacion_max: 1000,
                tipo_suelo: 'Ácido (turba)',
                ph_min: 4.5,
                ph_max: 5.5,
                altitud_min: 2000,
                altitud_max: 3200
            },
            costos: {
                inversion_min: 20000000,
                inversion_max: 30000000,
                costo_operativo: 10000000,
                precio_interno: 20000,
                precio_export: 5.50,
                rentabilidad: 35
            }
        }
    ];
}
